https://cutt.ly/fr
https://bitly.com